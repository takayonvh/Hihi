chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  // 1. Xử lý khi nhận được IMEI
  if (request.action === "IMEIValue") {
    const imeiDiv = document.getElementById("imei-div");
    const imeiInput = document.getElementById("imei-input");

    if (imeiDiv && imeiInput) {
      imeiDiv.classList.remove("is-disabled");
      imeiInput.disabled = false; // Kích hoạt input nếu trước đó bị disable
      imeiInput.value = request.imei;
    }

    // 2. Xử lý khi nhận được Cookies
  } else if (request.action === "CookiesValue") {
    const cookiesDiv = document.getElementById("cookies-div");
    const cookiesInput = document.getElementById("cookies-input");

    if (cookiesDiv && cookiesInput) {
      cookiesDiv.classList.remove("is-disabled");
      cookiesInput.disabled = false; // Kích hoạt input
      cookiesInput.value = request.cookies;
    }
  }

  // Trả về true để giữ kết nối message (nếu cần dùng sendResponse sau này)
  return true;
});
