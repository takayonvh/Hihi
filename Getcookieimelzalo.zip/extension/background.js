// background.js - Phiên bản Manifest V3 chuẩn

// 1. Hàm tạo thông báo (Notification)
function createNotification(title, message) {
  chrome.notifications.create({
    type: "basic",
    title: title,
    message: message,
    iconUrl: "images/success.png", // Đảm bảo bạn có file này trong thư mục images
    priority: 2,
  });
}

// 2. Lắng nghe yêu cầu mạng để bắt IMEI từ API Zalo
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    const url = details.url;

    // Kiểm tra đúng endpoint lấy thông tin server của Zalo có chứa IMEI
    if (url.includes("/api/login/getServerInfo") && url.includes("imei=")) {
      try {
        const urlObj = new URL(url);
        const imeiValue = urlObj.searchParams.get("imei");

        if (imeiValue) {
          // Lưu IMEI vào bộ nhớ đệm (Storage) để Popup có thể lấy bất cứ lúc nào
          chrome.storage.local.set({ last_imei: imeiValue });

          // Gửi dữ liệu trực tiếp về Popup (nếu Popup đang mở)
          chrome.runtime
            .sendMessage({
              action: "IMEIValue",
              imei: imeiValue,
            })
            .catch(() => {
              /* Bỏ qua lỗi nếu popup đang đóng */
            });

          createNotification("IMEI Found", "Đã lấy được IMEI: " + imeiValue);

          // 3. Sau khi bắt được IMEI, tiến hành lấy luôn Cookie của Zalo
          chrome.cookies.getAll({ domain: "zalo.me" }, (cookies) => {
            if (cookies && cookies.length > 0) {
              const cookiesDict = {};
              cookies.forEach((cookie) => {
                cookiesDict[cookie.name] = cookie.value;
              });

              const cookieJson = JSON.stringify(cookiesDict);

              // Lưu Cookie vào Storage
              chrome.storage.local.set({ last_cookies: cookieJson });

              // Gửi Cookie về Popup
              chrome.runtime
                .sendMessage({
                  action: "CookiesValue",
                  cookies: cookieJson,
                })
                .catch(() => {
                  /* Bỏ qua lỗi nếu popup đang đóng */
                });

              createNotification(
                "Cookies Found",
                "Đã lấy thành công Cookie Zalo.",
              );
            }
          });
        }
      } catch (error) {
        console.error("Lỗi xử lý URL:", error);
      }
    }
  },
  { urls: ["*://*.zalo.me/*"] },
);

// 4. Đảm bảo Service Worker luôn sẵn sàng
chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension Lấy IMEI & Cookie đã sẵn sàng trên Manifest V3!");
});
