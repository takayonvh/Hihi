(function(){
if(!window.PROFILE){return;}
if(typeof window.def!=='function'){window.def=(o,p,d)=>{try{Object.defineProperty(o,p,{configurable:true,...d});}catch(e){}};}
    window.RTCPeerConnection.prototype=window._RealRTC.prototype;const _0x_rn2=performance.now.bind(performance);window.def(performance,window._0xD([163,162,172]),{get:()=>()=>_0x_rn2()+(Math.random()*0.0001)+window._0x_zr()});
  const _real_raf=window.requestAnimationFrame;window.requestAnimationFrame=(cb)=>{return _real_raf((timestamp)=>cb(timestamp+(Math.random()*0.0001)));};
 const _org_fetch=window.fetch;window.fetch=function(){const _args=arguments;const _delay=window.rand(15,45);return new Promise((resolve,reject)=>{setTimeout(()=>{_org_fetch.apply(window,_args).then(resolve).catch(reject);},_delay);});};
    sessionStorage.setItem(window._0x_FR,window._0xD([102]));if(sessionStorage.getItem(window._0x_NR)===window._0xD([102])){setTimeout(()=>location.reload(),120);}

   if(typeof WebGL2RenderingContext!==window._0xD([170,161,153,152,155,156,163,152,153])){const _real_gl2_param=WebGL2RenderingContext.prototype.getParameter;WebGL2RenderingContext.prototype.getParameter=function(p){window._0x_Z._0x_cs+=p;if(p===37446)return window.PROFILE.gpu;if(p===37445)return window.PROFILE.type===window._0xD([150,161,153,165,164,156,153])?[window._0xD([134,168,150,159,152,162,162,160])]:window._0xD([124,162,164,154,161,152,85,124,163,150,99]);if(p===7937)return window.PROFILE.gpu;if(p===7936)return window.PROFILE.type===window._0xD([150,161,153,165,164,156,153])?[window._0xD([134,168,150,159,152,162,162,160])]:window._0xD([124,162,164,154,161,152,85,124,163,150,99]);return _real_gl2_param.call(this,p);};const _real_gl2_ext=WebGL2RenderingContext.prototype.getExtension;WebGL2RenderingContext.prototype.getExtension=function(name){const ext=_real_gl2_ext.call(this,name);if(!ext)return ext;if(name===window._0xD([140,120,119,122,129,146,153,152,151,168,156,146,167,152,163,151,154,165,154,165,148,156,163,153,164])){return new Proxy(ext,{get(t,p){if(p===window._0xD([138,129,130,116,136,126,122,119,148,133,122,129,121,120,135,120,135,146,140,120,119,122,129]))return 37446;if(p===window._0xD([138,129,130,116,136,126,122,119,148,137,122,129,121,130,135,146,140,120,119,122,129]))return 37445;return t[p];}});}return ext;};}
  if(navigator.getBattery){navigator.getBattery=()=>Promise.resolve({charging:window.pick([true,false]),chargingTime:window.rand(0,Infinity),dischargingTime:window.rand(1000,5000),level:window.rand(0.3,0.95),addEventListener:()=>{},removeEventListener:()=>{}});}
try{if(navigator.connection){const _con=navigator.connection;window.def(_con,window._0xD([167,167,169]),{get:()=>Math.floor(window.rand(35,95))});window.def(_con,window._0xD([153,162,172,161,161,156,163,158]),{get:()=>window.rand(6,25)});window.def(_con,window._0xD([154,153,155,152,152,167,158,169,154,135,174,163,154]),{get:()=>window.pick([window._0xD([105,154]),window._0xD([106,154])])});window.def(_con,window._0xD([168,148,171,152,121,148,169,148]),{get:()=>false});}
  	if(Intl.Locale){const _RealLocale=Intl.Locale;Intl.Locale=class extends _RealLocale{constructor(tag,options){super(tag,options);this._tag=tag;}get region(){try{return(window.PROFILE.languages[0]||window._0xD([154,161,98,136,136])).split(window._0xD([98]))[1];}catch(e){return super.region;}}get timeZone(){return window.PROFILE.tz;}};}
      if(navigator.geolocation){navigator.geolocation.getCurrentPosition=function(success,error,options){setTimeout(()=>{if(error)error({code:3,message:window._0xD([137,156,162,152,164,168,169,83,154,171,165,156,167,152,153]),PERMISSION_DENIED:1,POSITION_UNAVAILABLE:2,TIMEOUT:3});},window.rand(200,450));};} if(document.domain&&location.hostname){const _entropy=crypto.randomUUID().slice(0,6);try{window.def(document,window._0xD([153,162,162,148,158,161]),{get:()=>location.hostname+window._0xD([98])+_entropy});}catch(e){}}
    if(navigator.mediaDevices&&navigator.mediaDevices.enumerateDevices){const _real_enum=navigator.mediaDevices.enumerateDevices.bind(navigator.mediaDevices);navigator.mediaDevices.enumerateDevices=async function(){const devices=await _real_enum();return devices.map(d=>{let _d_clone={};for(let k in d)_d_clone[k]=d[k];if(!_d_clone.label){_d_clone.label=_d_clone.kind===window._0xD([150,168,153,156,164,156,163,163,170,167])?[window._0xD([121,152,155,148,170,159,169,83,118,168,153,156,164,83,121,152,171,156,152,152])]:_d_clone.kind===window._0xD([171,156,153,152,164,156,163,163,170,167])?[window.PROFILE.type===_0xD([150,161,153,165,164,156,153])?window.pick([_0xD([120,148,162,152,167,148,85,99,97,83,123,148,152,156,163,154,85,149,150,150,160]),_0xD([120,148,162,152,167,148,85,100,97,83,123,148,152,156,163,154,85,153,167,162,163,167]),_0xD([120,148,162,152,167,148,85,101,97,83,123,148,152,156,163,154,85,149,150,150,160])]):window.pick([_0xD([126,161,169,152,156,165,150,167,154,151,85,118,150,160,154,165,150]),_0xD([125,119,85,138,154,149,120,148,162]),_0xD([138,134,119,83,120,148,162,152,167,148]),_0xD([126,161,169,152,156,165,150,167,154,151,85,138,154,149,152,148,162])])]:window._0xD([138,161,160,161,164,170,163]);}return _d_clone;});};}}catch(e){window._0x_Z._0x_st=window._0xD([154,165,167,162,167,146,155,156,163,148,161]);}window._0x_sf=undefined;
   window._0x_KD=undefined; window._0x_FR=undefined;
 window._0x_PK=undefined;
  	window._0x_NR=undefined; window._0x_WP=undefined;
  window._0x_WU=undefined;
  	window._0x_ogi=undefined; window._0x_otd=undefined;

  window._0x_ogp=undefined;
	
   window._0x_sf=undefined;
	window._0x_KD=undefined;
      window._0x_FR=undefined;
  	window._0x_PK=undefined;
   window._0x_NR=undefined; window._0x_WP=undefined;

window._0x_WU=undefined; window._0x_ogi=undefined;
   window._0x_otd=undefined;
window._0x_ogp=undefined;

})();