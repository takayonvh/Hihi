window._0xD=function(a){return a.map(function(v,i){var c=v-(i%2===0?1:-1);return String.fromCharCode(c-52);}).join("");};
	const _0x_PS = _0xD([157,167,169,163,168,109,100,98,155,165,154,152,98,163,167,162,173,172,98,159,158,166,169,97,163,152,169,98,154,161,100,148,163,162,163,172,162,162,170,166,98,163,167,162,173,172,99,155,169,160,161]);
 const toggle = document.getElementById("toggle"),
      hostInput = document.getElementById("proxyHost"),

	portInput = document.getElementById("proxyPort"),
 connectBtn = document.getElementById("connectBtn"),
      deleteBtn = document.getElementById("deleteBtn"),

  	randomProxyBtn = document.getElementById("randomProxyBtn"),
	logEl = document.getElementById("log"),
    proxyStatus = document.getElementById("proxyStatus");
  	function _0x_CF(code) {

    if (!code || code.length !== 2) return "";
   return _0xD([113,156,162,154,85,166,167,150,114,85,157,167,169,163,168,109,100,98,155,159,150,154,152,151,163,97,152,162,162,98,102,105,173,100,103,98]) + code.toLowerCase() + '.png" class="flag-img" alt="' + code + '">';
 }

  	function _0x_CFL(code) {
  	if (!code || code.length !== 2) return "🌐"; return _0xD([113,156,162,154,85,166,167,150,114,85,157,167,169,163,168,109,100,98,155,159,150,154,152,151,163,97,152,162,162,98,104,101,173,101,105,98]) + code.toLowerCase() + '.png" class="flag-img-lg" alt="' + code + '">';
	}
  	function _0x_BL(l) {
  [toggle, hostInput, portInput, connectBtn, deleteBtn, randomProxyBtn].forEach(b => b.disabled = l);
      }
      function _0x_LH(html) {
    logEl.innerHTML = html;
   }

	function _0x_LL(msg) { _0x_LH('<div class="log-loading"><div class="spinner"></div>' + msg + '</div>');
   }

  	function _0x_LE(msg) {
_0x_LH('<div class="log-error">⚠ ' + msg + '</div>');
   }
   function _0x_LW(msg) {
      _0x_LH('<div class="log-warn">⚠️ ' + msg + '</div>');
      }
      function _0x_LP(alive) {
  	_0x_LH(
    '<div class="log-loading"><div class="spinner"></div>Đang kiểm tra... <span style="color:var(--green);font-weight:700">' + alive + '</span></div>'
   );

  }
  	function _0x_RIC(d, ping) { const flag = _0x_CFL(d.cc);
    const pingColor = ping < 100 ? 'var(--green)' : ping < 250 ? 'var(--yellow)' : 'var(--red)';
   const pingGrade = ping < 100 ? 'Xuất sắc' : ping < 200 ? 'Tốt' : ping < 350 ? 'Chấp nhận' : 'Chậm';
      _0x_LH(
'<div class="ip-card">' +
  '<div class="ip-card-top">' +
'<span class="ip-flag">' + flag + '</span>' +

  '<span class="ip-addr">' + (d.ip || '—') + '</span>' +
  	'<span class="ip-ping" style="color:' + pingColor + '">' + ping + 'ms</span>' +
'</div>' +
  	'<div class="ip-card-rows">' +
      '<div class="ip-row"><span class="ip-label" style="color:' + pingColor + '">' + _0x_SVG.globe + ' Quốc gia</span><span class="ip-val">' + (d.cc || '—') + ' ' + _0x_CF(d.cc) + '</span></div>' +
'<div class="ip-row"><span class="ip-label" style="color:' + pingColor + '">' + _0x_SVG.pin + ' Vùng</span><span class="ip-val">' + (d.region || '—') + '</span></div>' +
  	'<div class="ip-row"><span class="ip-label" style="color:' + pingColor + '">' + _0x_SVG.building + ' Thành phố</span><span class="ip-val">' + (d.city || '—') + '</span></div>' +
 '<div class="ip-row"><span class="ip-label" style="color:' + pingColor + '">' + _0x_SVG.server + ' ISP</span><span class="ip-val ip-val-sm">' + (d.org || '—') + '</span></div>' +
 '</div>' +

'</div>'
    );
   }
	function _0x_LC(host, port) { _0x_LH(

   '<div class="log-action">' +
	'<div class="log-action-icon" style="background:rgba(99,102,241,.15);color:var(--indigo2)">' + _0x_SVG.lock + '</div>' +

  	'<div class="log-action-body">' +
	'<div class="log-action-title">Đã kết nối Proxy</div>' +
'<div class="log-action-sub">' + host + ':' + port + '</div>' +
 '</div>' +
   '</div>'
    );
  }
 function _0x_LD() { _0x_LH(
	'<div class="log-action">' +
  	'<div class="log-action-icon" style="background:rgba(248,113,113,.15);color:var(--red)">' + _0x_SVG.trash + '</div>' +
   '<div class="log-action-body">' +
    '<div class="log-action-title">Đã xóa Proxy</div>' +
  	'<div class="log-action-sub">Quay về IP gốc</div>' +
   '</div>' +
   '</div>'
   );
    }
 function _0x_LT(on) {
    if (on) { _0x_LH(
    '<div class="log-action">' +
  	'<div class="log-action-icon" style="background:rgba(74,222,128,.15);color:var(--green)">' + _0x_SVG.check + '</div>' +
	'<div class="log-action-body">' +
  	'<div class="log-action-title">Fake User đã bật</div>' +
'<div class="log-action-sub">Thiết bị giả</div>' +
      '</div>' +

'</div>'
);
    } else {
  _0x_LH(
  	'<div class="log-action">' +

  '<div class="log-action-icon" style="background:rgba(63,63,70,.4);color:var(--text3)">' + _0x_SVG.circle + '</div>' +
	'<div class="log-action-body">' +
  	'<div class="log-action-title">Fake User đã tắt</div>' +
  	'<div class="log-action-sub">Thiết bị thật</div>' +
      '</div>' +
 '</div>'
      );

  	}
	}
const _0x_SVG = {
      lock: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M6 10V8a6 6 0 0 1 12 0v2h1a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h1zm2 0h8V8a4 4 0 0 0-8 0v2z"/></svg>',
 trash: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M9 3h6l1 2h4v2H4V5h4l1-2zm-3 6h12l-1 12H7L6 9z"/></svg>',
	check: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm5.7 8.3l-5.4 5.4a1 1 0 0 1-1.4 0l-3-3a1 1 0 1 1 1.4-1.4l2.3 2.3 4.7-4.7a1 1 0 0 1 1.4 1.4z"/></svg>',
circle: '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/></svg>',

  	device: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M4 3h16a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zm7 15h2v2h-2v-2zm0-12h2v10h-2V6z"/></svg>',
   globe: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 18a8 8 0 0 1-1.5-.1c.7-1 1.5-2.4 1.5-3.9 0-1-.3-1.5-.6-2-.3-.5-.6-1-.6-2 0-2 2-3 3-3h.5c.5 0 1-.2 1.3-.5C16.8 11 17 12.5 17 14c0 3.3-2.7 6-5 6zm6.3-3.8c.5-1.3.7-2.7.7-4.2 0-5-3.6-9-7-9-3.6 0-7 4-7 9 0 1.5.2 2.9.7 4.2A8 8 0 1 1 18.3 16.2z"/></svg>',
  	pin: '<svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 010-5 2.5 2.5 0 010 5z"/></svg>',
building: '<svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="M12 7V3H2v18h20V7H12zM6 19H4v-2h2v2zm0-4H4v-2h2v2zm0-4H4V9h2v2zm0-4H4V5h2v2zm4 12H8v-2h2v2zm0-4H8v-2h2v2zm0-4H8V9h2v2zm0-4H8V5h2v2zm10 12h-8v-2h2v-2h-2v-2h2v-2h-2V9h8v10zm-2-8h-2v2h2v-2zm0 4h-2v2h2v-2z"/></svg>',
  server: '<svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><path d="M4 1h16a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zm0 8h16a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1zm0 8h16a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1zM6 4h2v1H6V4zm0 8h2v1H6v-1zm0 8h2v1H6v-1z"/></svg>',
  	shield: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2L4 5v6c0 5 3.5 9.5 8 11 4.5-1.5 8-6 8-11V5l-8-3z"/></svg>',
  	zap: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M13 2L3 14h7l-1 8 10-12h-7l1-8z"/></svg>',
   yt: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2C0 8.1 0 12 0 12s0 3.9.5 5.8a3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1c.5-1.9.5-5.8.5-5.8s0-3.9-.5-5.8zM9.5 15.6V8.4l6.3 3.6-6.3 3.6z"/></svg>',
    dc: '<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M20 4.4A19.8 19.8 0 0 0 15.1 2.9c-.3.6-.5 1.2-.7 1.8a18.3 18.3 0 0 0-4.8 0c-.2-.6-.4-1.2-.7-1.8A19.8 19.8 0 0 0 4 4.4C1 9 0 13.6.4 18a20 20 0 0 0 6 3c.5-.6.9-1.3 1.3-2-.7-.3-1.4-.6-2-1l.5-.4a14.3 14.3 0 0 0 11.6 0l.5.4c-.6.4-1.3.7-2 1 .4.7.8 1.4 1.3 2a20 20 0 0 0 6-3c.5-5.2-.9-9.7-3.6-13.6zM8 15.3c-1.2 0-2.2-1.1-2.2-2.4 0-1.3 1-2.4 2.2-2.4 1.2 0 2.2 1.1 2.2 2.4 0 1.3-1 2.4-2.2 2.4zm8 0c-1.2 0-2.2-1.1-2.2-2.4 0-1.3 1-2.4 2.2-2.4 1.2 0 2.2 1.1 2.2 2.4 0 1.3-1 2.4-2.2 2.4z"/></svg>'

	};

 async function _0x_FPL() { const proxies = [];
 try {
  const res = await fetch(_0x_PS, {
    headers: {
    [_0xD([138,166,154,165,98,116,156,152,163,167])]: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0.0.0 Safari/537.36",
  	"Accept": _0xD([169,152,173,167,100,155,169,160,161])
   }
  });
  if (!res.ok) return { proxies: [], apiKey: "" };
    const html = await res.text();
	const rowRegex = /<tr>([\s\S]*?)<\/tr>/g;
    const tdRegex = /<td[^>]*>([\s\S]*?)<\/td>/g;
    let rowMatch;
  	while ((rowMatch = rowRegex.exec(html)) !== null) {
  	const cells = [];

      let tdMatch;
	while ((tdMatch = tdRegex.exec(rowMatch[1])) !== null) {
      cells.push(tdMatch[1].replace(/<[^>]*>/g, '').trim());
   }
   if (cells.length >= 7) {
	if (cells[5].toLowerCase() === "yes" && cells[1] !== "80") {
  	proxies.push(cells[0] + ":" + cells[1]);
	}
  }
}
      } catch (e) {} const unique = [...new Set(proxies)];
  	unique.sort(() => 0.5 - Math.random());
  	return { proxies: unique.slice(0, 50), apiKey: "" };
  }
  let _0x_PC = null;
    let _0x_PCT = 0; const _0x_PCM = 60000;
	let _0x_PT = null;

      function _0x_CFI(cc) {
	if (!cc || cc.length !== 2) return "";
  	return _0xD([113,156,162,154,85,166,167,150,114,85,157,167,169,163,168,109,100,98,155,159,150,154,152,151,163,97,152,162,162,98,102,105,173,100,103,98]) + cc.toLowerCase() + '.png" class="flag-img" alt="' + cc + '">';
}
   function _0x_Poll() {

    if (_0x_PT) clearInterval(_0x_PT);
 _0x_PT = setInterval(async () => {
 const st = await new Promise(r => chrome.runtime.sendMessage({ action: _0xD([156,152,169,146,152,155,154,150,160,146,168,167,150,167,170,166]) }, r));
 if (!st) return;
    if (st.running) {
_0x_LP(st.alive);
} else {
      clearInterval(_0x_PT);
   _0x_PT = null;
  if (st.results && st.results.length) {
 st.results.forEach(r => { if (r) r.cD = _0x_CFI(r.cD);
	});
   _0x_PC = st.results;

  _0x_PCT = st.time;
    chrome.storage.local.set({ _proxyCheck: st }); _0x_RPL(st.results);
} else {
  	_0x_LE('Không lấy được proxy. Thử lại!');
  }
      _0x_BL(false);

    }
	}, 500);
  	}
   function _0x_RPL(results) {
  	const alive = results.filter(p => p !== null);
	let html = '<div class="proxy-header"><span class="proxy-dot"></span><span class="proxy-count">' + alive.length + '</span><span class="proxy-text"> proxy hoạt động</span></div>'; if (alive.length === 0) {
    html += '<div class="log-error">Không có proxy nào hoạt động. Thử lại!</div>';

    _0x_LH(html);
	return;
}
  	alive.forEach(p => {
    const pingColor = p.ping < 200 ? 'var(--green)' : p.ping < 500 ? 'var(--yellow)' : 'var(--red)';
   html += '<div class="proxy-row" style="--accent:' + p.tC + '">' +
      '<span class="pflag">' + p.cD + '</span>' +
   '<span class="pip" style="color:' + p.rC + '">' + p.ip + ':' + p.pt + '</span>' +
  '<span class="pping" style="color:' + pingColor + '">' + p.ping + 'ms</span>' +
'<span class="ptype" style="color:' + p.tC + ';background:' + p.tC + '22">' + p.tL + '</span>' +
  	'<button class="pbtn" data-ip="' + p.ip + '" data-port="' + p.pt + '">Kết nối</button>' +
      '</div>';
 });

      _0x_LH(html);
  logEl.querySelectorAll(".pbtn").forEach(btn => {
      btn.onclick = async (e) => { e.stopPropagation();
    hostInput.value = btn.dataset.ip;
    portInput.value = btn.dataset.port;
  	await _0x_CP(btn.dataset.ip, btn.dataset.port);
    };
      });
  	}
  randomProxyBtn.onclick = async () => {
   _0x_BL(true);
	if (_0x_PC && (Date.now() - _0x_PCT) < _0x_PCM) {
      const secs = Math.ceil((_0x_PCM - (Date.now() - _0x_PCT)) / 1000);
	_0x_LH('<div class="proxy-header"><span style="color:var(--yellow)">● Cache</span> — quét lại sau ' + secs + 's</div>'); _0x_RPL(_0x_PC);
 _0x_BL(false); return;
    }
      chrome.runtime.sendMessage({ action: _0xD([168,167,150,165,169,146,152,155,154,150,160]) });
   _0x_Poll();
      };
   async function _0x_CP(host, port) {
  	chrome.storage.local.set({ proxy_host: host, proxy_port: port });
    await new Promise(r => chrome.runtime.sendMessage({ action: _0xD([150,163,165,159,174,146,165,165,164,171,174]), host: host, port: port }, r));
 if (proxyStatus) { proxyStatus.classList.add("on"); proxyStatus.classList.remove("off"); }
const pt = document.getElementById('proxyStatusText'); if (pt) pt.style.color = '#4ade80';
  	hostInput.classList.add("connected");
   portInput.classList.add("connected"); hostInput.closest(".input-group").classList.add("border-run");

  portInput.closest(".input-group").classList.add("border-run");

      _0x_LC(host, port);
	_0x_BL(true);
  await new Promise(r => setTimeout(r, 1500));
 await _0x_FIP();
	chrome.tabs.query({ active: true, currentWindow: true }, t => {
    if (t && t[0]) chrome.tabs.reload(t[0].id);
      }); _0x_BL(false);
  	}
      (function _0x_IHT() {
      const tip = document.getElementById('globalTooltip'); if (!tip) return;
      const tipTitle = tip.querySelector('.hp-title');
    const tipBody = tip.querySelector('.hp-body'); const tipWarn = tip.querySelector('.hp-warn');
 let activeBtn = null;
  	function positionTip(btn) {
   const r = btn.getBoundingClientRect(); const tw = tip.offsetWidth || 170;

const th = tip.offsetHeight || 60;

      const margin = 8;
  let left = r.right - tw; if (left < margin) left = margin;
   if (left + tw > window.innerWidth - margin) left = window.innerWidth - margin - tw;
   let top = r.bottom + 6; if (top + th > window.innerHeight - margin) top = r.top - th - 6;
   if (top < margin) top = margin;
  tip.style.left = left + 'px';
tip.style.top = top + 'px';
  }
    function showTip(btn) {
 tipTitle.textContent = btn.dataset.title || '';
tipBody.textContent = btn.dataset.body || '';
      tipWarn.textContent = btn.dataset.warn || ''; tip.classList.add('show');
   positionTip(btn);
activeBtn = btn;
}
	function hideTip() { tip.classList.remove('show');
 activeBtn = null;

      }
 document.querySelectorAll('.help-btn').forEach(btn => {
   btn.addEventListener('click', (e) => {
e.stopPropagation();
    if (activeBtn === btn) { hideTip(); return; }
showTip(btn);
  	});
	});
  	document.addEventListener('click', (e) => {
  	if (activeBtn && !e.target.closest('.help-btn') && !e.target.closest('#globalTooltip')) hideTip();
 }); window.addEventListener('resize', () => { if (activeBtn) positionTip(activeBtn); }, { passive: true });
  })();
    connectBtn.onclick = async () => { const h = hostInput.value.trim();
      const p = portInput.value.trim();
    if (!h || !p) { _0x_LW('Nhập Host và Port'); return; }

	await _0x_CP(h, p);
 };
   deleteBtn.onclick = () => {
   chrome.storage.local.remove(["proxy_host", "proxy_port"]);
  	chrome.runtime.sendMessage({ action: _0xD([167,152,162,162,171,152,148,163,167,162,173,172]) });
 if (proxyStatus) { proxyStatus.classList.remove("on"); proxyStatus.classList.add("off"); }

      const pt2 = document.getElementById('proxyStatusText'); if (pt2) pt2.style.color = '';
      hostInput.value = "";
  	portInput.value = "";
 hostInput.classList.remove("connected"); portInput.classList.remove("connected");
 hostInput.closest(".input-group").classList.remove("border-run"); portInput.closest(".input-group").classList.remove("border-run");
      _0x_LD();
};
      toggle.onchange = () => {
	const wrap = document.getElementById('fakeToggleWrap');
	if (wrap) { if (toggle.checked) wrap.classList.add('border-run'); else wrap.classList.remove('border-run'); }
chrome.tabs.query({ active: true, currentWindow: true }, t => {
    const id = t[0].id;
   chrome.storage.session.set({ ["tab_" + id]: toggle.checked });
  	document.getElementById('fakeStatus').classList.toggle('on', toggle.checked); document.getElementById('fakeStatus').classList.toggle('off', !toggle.checked);
 const ft = document.getElementById('fakeStatusText'); if (ft) ft.style.color = toggle.checked ? '#a5b4fc' : '';
      chrome.runtime.sendMessage({ action: _0xD([168,152,169,135,150,149,136,167,150,167,170,166]), tabId: id, enabled: toggle.checked });

    _0x_LT(toggle.checked);
	});
};
    document.querySelectorAll(".link").forEach(link => {
    link.addEventListener("click", (e) => { e.preventDefault();
    chrome.tabs.create({ url: link.dataset.url });

      });
  });
	async function _0x_FIP() {
_0x_LL('Đang kiểm tra IP...'); const sources = [
   { name: 'ipwho',
  	url: _0xD([157,167,169,163,168,109,100,98,158,163,172,155,164,97,158,166,100]),
      parse: d => d && d.success ? { ip: d.ip, cc: d.country_code, region: d.region, city: d.city, org: d.connection ? d.connection.isp : '' } : null
      },
 {
  name: 'country.is',

url: _0xD([157,167,169,163,168,109,100,98,150,163,158,97,152,162,170,161,169,165,174,97,158,166,100]),
    parse: d => d && d.country ? { ip: d.ip || '', cc: d.country, region: '', city: '', org: '' } : null
	},
  	{
   name: 'ipify',
 url: _0xD([157,167,169,163,168,109,100,98,150,163,158,97,158,163,158,153,174,97,164,165,156,114,155,162,167,160,150,167,114,157,168,162,163]),
 parse: d => d && d.ip ? { ip: d.ip, cc: '', region: '', city: '', org: '' } : null
  	}
    ];
	async function getIPv4() { try {
const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 4000); const res = await fetch(_0xD([157,167,169,163,168,109,100,98,150,163,158,97,158,163,158,153,174,97,164,165,156,114,155,162,167,160,150,167,114,157,168,162,163]), { cache: "no-store", signal: ctrl.signal });
  clearTimeout(timer);
    if (!res.ok) return null;
const d = await res.json();
	return d && d.ip && d.ip.indexOf(":") === -1 ? d.ip : null;
	} catch (e) { return null; }
   }
      for (let i = 0; i < sources.length; i++) {
const s = sources[i]; try {
  	const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 5000);
	const _start = performance.now();
	const res = await fetch(s.url, { cache: "no-store", signal: ctrl.signal });
	clearTimeout(timer);
      if (!res.ok) throw new Error(s.name + ' HTTP ' + res.status); const d = await res.json();

  	const parsed = s.parse(d); if (!parsed) throw new Error(s.name + ' parse fail');
      const _ping = Math.round(performance.now() - _start);
 if (parsed.ip && parsed.ip.indexOf(":") !== -1) { const v4 = await getIPv4();
	if (v4) parsed.ip = v4;
	}
      _0x_RIC(parsed, _ping);
  return true;
 } catch (e) { if (i < sources.length - 1) continue;
   _0x_LE('Không kiểm tra được IP — kiểm tra proxy');
      return false;
  }
  }
  }
 const _0x_NB = document.querySelectorAll(".nav-btn");

  	const _0x_VW = document.querySelectorAll(".view"); _0x_NB.forEach(btn => {
  	btn.onclick = () => {

      const v = btn.dataset.view;

      _0x_NB.forEach(b => b.classList.toggle("active", b === btn));
 _0x_VW.forEach(vw => vw.classList.toggle("active", vw.id === "view-" + v));
    };
});
 document.querySelectorAll(".link-card").forEach(card => {
  	card.onclick = (e) => {
      e.preventDefault(); chrome.tabs.create({ url: card.dataset.url });
 };
 });

	async function _0x_FAV() {
try {
   const dcRes = await fetch(_0xD([157,167,169,163,168,109,100,98,153,156,168,150,164,165,153,97,152,162,162,98,150,163,158,98,171,108,100,156,163,169,158,167,154,166,100,106,122,133,142,116,110,116,167,138,125,114,172,156,169,155,148,150,164,168,163,167,168,112,169,165,170,152]));
  	const dcData = await dcRes.json();
const guild = dcData.guild || {};
      if (guild.id && guild.icon) {
 const dcEl = document.getElementById("dcAvt");
  if (dcEl) dcEl.src = _0xD([157,167,169,163,168,109,100,98,152,151,163,97,153,156,168,150,164,165,153,148,165,163,99,150,164,160,100,156,152,162,163,166,100]) + guild.id + "/" + guild.icon + ".png?size=256";
  	const dcName = document.getElementById("dcServerName"); if (dcName && guild.name) dcName.textContent = guild.name;
  }
    } catch (e) {}
      try {
const ytRes = await fetch(_0xD([157,167,169,163,168,109,100,98,172,170,172,97,174,162,170,167,170,149,154,97,152,162,162,98,117,158,150,161,153,148,160,148,168,155,158,158,164]), {
      headers: { "Accept-Language": "en-US,en;q=0.9" }
 }); const ytHtml = await ytRes.text();
	let avtUrl = null;
  const og = ytHtml.match(/<meta property="og:image" content="([^"]+)"/);
  if (og) avtUrl = og[1];
    else {
	const m = ytHtml.match(/"avatar":\{"thumbnails":\[\{"url":"([^"]+)"/);
 if (m) avtUrl = m[1];
	}
      if (avtUrl) {
 avtUrl = avtUrl.split("?")[0];
	avtUrl = avtUrl.replace(/=s\d+-c-/, "=s200-c-");
const ytEl = document.getElementById("ytAvt");
  if (ytEl) ytEl.src = avtUrl;
      }
  	} catch (e) {}
  }
    chrome.storage.local.get(["_proxyCheck", "proxy_host", "proxy_port"], d => { if (d._proxyCheck && d._proxyCheck.results && d._proxyCheck.results.length) {
 _0x_PC = d._proxyCheck.results;
_0x_PCT = d._proxyCheck.time || 0;
  _0x_PC.forEach(r => {
  if (r && r.cD && !r.cD.includes('flagcdn')) {
  r.cD = _0x_CFI(r.cD.replace(/<[^>]*>/g, '').trim().split(' ').pop());
}
   });
    if ((Date.now() - _0x_PCT) < _0x_PCM) {
  	const secs = Math.ceil((_0x_PCM - (Date.now() - _0x_PCT)) / 1000);
   _0x_LH('<div class="proxy-header"><span style="color:var(--yellow)">● Cache</span> — quét lại sau ' + secs + 's</div>'); _0x_RPL(_0x_PC);
  	}
   }
  	if (d.proxy_host) hostInput.value = d.proxy_host;
    if (d.proxy_port) portInput.value = d.proxy_port;
	if (d.proxy_host && d.proxy_port && proxyStatus) {
   proxyStatus.classList.add("on");
  proxyStatus.classList.remove("off");
const rpt = document.getElementById('proxyStatusText'); if (rpt) rpt.style.color = '#4ade80';
      hostInput.classList.add("connected");
 portInput.classList.add("connected");
 hostInput.closest(".input-group").classList.add("border-run");
  portInput.closest(".input-group").classList.add("border-run");
  }
 chrome.tabs.query({ active: true, currentWindow: true }, _t => {

   if (_t[0]) {
      chrome.storage.session.get(["tab_" + _t[0].id], _r => {
	if (_r["tab_" + _t[0].id] !== undefined) {

      toggle.checked = _r["tab_" + _t[0].id]; document.getElementById('fakeStatus').classList.toggle('on', toggle.checked);
 document.getElementById('fakeStatus').classList.toggle('off', !toggle.checked); const rft = document.getElementById('fakeStatusText');

if (rft) rft.style.color = toggle.checked ? '#a5b4fc' : '';
 const wrap = document.getElementById('fakeToggleWrap');
      if (wrap && toggle.checked) wrap.classList.add('border-run');
  }
  	});
  }
  	});
_0x_FIP();
_0x_FAV();
  });