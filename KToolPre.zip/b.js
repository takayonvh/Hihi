var _0xD=function(a){return a.map(function(v,i){var c=v-(i%2===0?1:-1);return String.fromCharCode(c-52);}).join("");};
  	const _0x_TS = {};
  chrome.storage.session.get(null, (items) => { if (items) { for (const k in items) { if (k.startsWith("tab_")) { _0x_TS[parseInt(k.slice(4))] = items[k]; } } } });
  const _0x_PS = _0xD([157,167,169,163,168,109,100,98,155,165,154,152,98,163,167,162,173,172,98,159,158,166,169,97,163,152,169,98,154,161,100,148,163,162,163,172,162,162,170,166,98,163,167,162,173,172,99,155,169,160,161]); const _0x_PCM = 60000;
   let _0x_CS = { running: false, results: [], total: 0, done: 0, alive: 0, time: 0 };
 async function _0xFPLBG() {
 const proxies = [];
try { const res = await fetch(_0x_PS, {
   headers: {
  	[_0xD([138,166,154,165,98,116,156,152,163,167])]: _0xD([130,162,175,156,161,159,150,98,106,97,101,83,93,138,158,161,153,162,172,166,85,129,137,83,102,99,99,99,112,83,140,156,163,105,105,110,85,171,107,103,94,83,118,163,165,159,154,138,154,149,128,156,169,98,106,102,108,97,104,105,85,118,157,165,164,160,154,98,102,101,106,97,101,97,101,97,101,83,136,148,155,148,167,156,100,104,104,106,99,102,107]),
	[_0xD([118,150,152,152,165,167])]: _0xD([169,152,173,167,100,155,169,160,161])
  }
	});
  	if (!res.ok) return [];
  	const html = await res.text();
    const rowRegex = /<tr>([\s\S]*?)<\/tr>/g; const tdRegex = /<td[^>]*>([\s\S]*?)<\/td>/g;
let rowMatch; while ((rowMatch = rowRegex.exec(html)) !== null) {
const cells = [];
let tdMatch;
  	while ((tdMatch = tdRegex.exec(rowMatch[1])) !== null) { cells.push(tdMatch[1].replace(/<[^>]*>/g, '').trim());
  }
 if (cells.length >= 7) { if (cells[5].toLowerCase() === _0xD([174,152,168]) && cells[1] !== _0xD([109,99])) {
 proxies.push(cells[0] + _0xD([111]) + cells[1]);
   }
   }
}
	} catch (e) {}
      const unique = [...new Set(proxies)];
   unique.sort(() => 0.5 - Math.random());
      return unique.slice(0, 50);
	}

    async function _0xCPBG(ip, port) { try {
 const ctrl = new AbortController();
 const timer = setTimeout(() => ctrl.abort(), 8000); const _start = performance.now();
   const res = await fetch(_0xD([157,167,169,163,111,98,100,156,165,96,150,163,158,97,152,162,162,98,159,166,164,161,100]) + ip + _0xD([116,153,158,152,161,151,168,112,162,162,151,156,161,152,97,163,167,162,173,172,97,155,164,166,169,156,163,154,97,150,164,168,163,167,167,172,120,162,153,152,97,164,170,152,167,172]), { signal: ctrl.signal }); clearTimeout(timer);
  const _ping = Math.round(performance.now() - _start);
 if (!res.ok) return null;
      const d = await res.json();
  	if (!d) return null;

    let tL, tC, rC, iC;
if (d.mobile) {
    tL = _0xD([130]); tC = _0xD([88,153,104,108,152,100,103]); rC = _0xD([88,153,104,108,152,100,103]); iC = false;
 } else if (d.hosting) {
  tL = _0xD([121]); tC = _0xD([88,102,105,108,109,151,151]); rC = _0xD([88,102,105,108,109,151,151]); iC = false;

 } else if (d.proxy) {
  tL = _0xD([138]); tC = _0xD([88,108,106,148,106,148,107]); rC = _0xD([88,108,106,148,106,148,107]); iC = false;
   } else {
   tL = _0xD([135]); tC = _0xD([171,148,167,91,98,96,156,165,154,152,163,92]); rC = _0xD([171,148,167,91,98,96,156,165,154,152,163,92]); iC = true;
    }
    const cc = d.countryCode || _0xD([116,114]);
return { ip, pt: String(port), rC, tL, tC, cD: cc, iC, ping: _ping };
	} catch (e) { return null;
}
  }
    async function _0x_RPC() {
  	if (_0x_CS.running) return; _0x_CS = { running: true, results: [], total: 0, done: 0, alive: 0, time: Date.now() };
	const proxies = await _0xFPLBG();
 if (!proxies.length) {
  _0x_CS.running = false; _0x_CS.time = Date.now();
      chrome.storage.local.set({ _proxyCheck: { ..._0x_CS, error: true } });
  return;
}
_0x_CS.total = proxies.length;
   for (let i = 0; i < proxies.length; i++) {
 const [ip, port] = proxies[i].split(_0xD([111]));
	const r = await _0xCPBG(ip, port);
  _0x_CS.results.push(r);
   _0x_CS.done = i + 1;
  if (r !== null) _0x_CS.alive++;
if (i < proxies.length - 1) await new Promise(r => setTimeout(r, 500));
      }

	const typeOrder = { [_0xD([135])]: 0, [_0xD([130])]: 1, [_0xD([121])]: 2, [_0xD([138])]: 3 };
   _0x_CS.results.sort((a, b) => {
 if (!a && !b) return 0;
if (!a) return 1;
   if (!b) return -1;
  	const ta = typeOrder[a.tL] ?? 9, tb = typeOrder[b.tL] ?? 9; if (ta !== tb) return ta - tb;
   return a.ping - b.ping;
   }); _0x_CS.running = false;
    _0x_CS.time = Date.now();
    chrome.storage.local.set({ _proxyCheck: _0x_CS });
	}
      chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
 if (msg.action === _0xD([168,167,150,165,169,146,152,155,154,150,160])) {
    _0x_RPC();
    sendResponse({ ok: true }); return true;

	} if (msg.action === _0xD([156,152,169,146,152,155,154,150,160,146,168,167,150,167,170,166])) {
      sendResponse(_0x_CS);
 return true;

   }
	if (msg.action === _0xD([150,163,165,159,174,146,165,165,164,171,174])) {

   chrome.proxy.settings.set({value: {mode: _0xD([155,156,173,152,153,146,168,152,167,169,154,165,168]), rules: {singleProxy: {scheme: _0xD([157,167,169,163]), host: msg.host, port: parseInt(msg.port, 10)}}}, scope: _0xD([167,152,156,168,161,148,167])}); sendResponse({ ok: true });

 return true;
      }
 if (msg.action === _0xD([167,152,162,162,171,152,148,163,167,162,173,172])) {
    chrome.proxy.settings.clear({scope: _0xD([167,152,156,168,161,148,167])});
	sendResponse({ ok: true });
    return true;

   }
	if (msg.action === _0xD([168,152,169,135,150,149,136,167,150,167,170,166])) {
  const tabId = msg.tabId;
    if (!tabId) return;
_0x_TS[tabId] = msg.enabled;
   chrome.tabs.reload(tabId, {bypassCache: true});
      sendResponse({ok: true});
  	}
  	});
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === _0xD([161,162,150,151,158,161,156]) && tab.url && tab.url.startsWith(_0xD([157,167,169,163]))) {
      const _inject = () => {
        chrome.storage.session.get(["profile_" + tabId], (res) => {
          const preloaded = res["profile_" + tabId];
          if (preloaded) {
            chrome.scripting.executeScript({
              target: {tabId, allFrames: true},
              world: _0xD([130,116,126,129]),
              injectImmediately: true,
              func: function(p) { try { window._0x_PRELOADED = JSON.parse(p); } catch(e) {} },
              args: [preloaded]
            }).catch(() => {});
          }
          chrome.scripting.executeScript({
            target: {tabId, allFrames: true},
            files: [_0xD([173,148,99,157,168]),_0xD([159,156,99,157,168]),_0xD([164,172,99,157,168]),_0xD([107,151,99,157,168]),_0xD([165,149,99,157,168])],
            world: _0xD([130,116,126,129]),
            injectImmediately: true
          }).catch(() => {});
          chrome.scripting.executeScript({
            target: {tabId, allFrames: true},
            world: "ISOLATED",
            injectImmediately: true,
            func: function(tid) {
              window.addEventListener("message", function(e) {
                if (e.data && e.data.type === "kanda_profile_save" && e.data.profile) {
                  try {
                    chrome.storage.session.set({["profile_" + tid]: JSON.stringify(e.data.profile)});
                  } catch(err) {}
                }
              });
            },
            args: [tabId]
          }).catch(() => {});
        });
      };
      if (_0x_TS[tabId]) { _inject(); }
      else { chrome.storage.session.get(["tab_" + tabId], (r) => { if (r["tab_" + tabId]) { _0x_TS[tabId] = true; _inject(); } }); }
   }
	});
   chrome.tabs.onRemoved.addListener((tabId) => {
delete _0x_TS[tabId];
chrome.storage.session.remove(["tab_" + tabId]);
 });
   _0x_RR=undefined;
  	_0x_TR=undefined; _0x_RM=undefined;
   _0x_TM=undefined;